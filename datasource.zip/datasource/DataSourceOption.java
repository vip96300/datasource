package com.xcwl.b2c.product.infrastructrue.config.datasource;

/**
 * 数据源选项
 */
public enum DataSourceOption {

    FUJIAN,CHONGQING;

}
