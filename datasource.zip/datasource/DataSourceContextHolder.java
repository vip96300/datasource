package com.xcwl.b2c.product.infrastructrue.config.datasource;

/**
 * @author huang hong fei
 * @description
 * @date 15:59
 */
public class DataSourceContextHolder {

    private static final ThreadLocal<DataSourceOption> dataSourceHolder=new ThreadLocal<>();

    public static void setDataSourceHolder(DataSourceOption dataSourceOption){
        dataSourceHolder.set(dataSourceOption);
    }

    public static DataSourceOption getDataSourceHolder() {
        return dataSourceHolder.get();
    }
}
