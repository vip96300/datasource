package com.xcwl.b2c.product.infrastructrue.config.datasource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * @author huang hong fei
 * @description
 * @date 16:02
 */
@Configuration
public class DataSourceConfig {

    @Primary
    @Bean
    public DynamicDataSource dataSource(@Qualifier("db_fujian") DataSource fuJianDB,@Qualifier("db_chongqing") DataSource chongQingDB) {
         Map<Object, Object> targetDataSources = new HashMap<>();
         targetDataSources.put(DataSourceOption.FUJIAN, fuJianDB);
         targetDataSources.put(DataSourceOption.CHONGQING, chongQingDB);
         DynamicDataSource dataSource = new DynamicDataSource();
         dataSource.setTargetDataSources(targetDataSources);
         dataSource.setDefaultTargetDataSource(fuJianDB);
         return dataSource;
    }

    /**
     * 根据数据源创建SqlSessionFactory
     * @param dynamicDataSource
     * @return
     * @throws Exception
     */
      @Bean
      public SqlSessionFactory sqlSessionFactory(DynamicDataSource dynamicDataSource) throws Exception {
            SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
            sqlSessionFactoryBean.setDataSource(dynamicDataSource);
         return sqlSessionFactoryBean.getObject();
      }

      @Bean
      public DataSourceTransactionManager transactionManager(DynamicDataSource dataSource) throws Exception {
          return new DataSourceTransactionManager(dataSource);
      }
}
