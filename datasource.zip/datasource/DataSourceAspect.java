package com.xcwl.b2c.product.infrastructrue.config.datasource;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;

/**
 * @author huang hong fei
 * @description
 * @date 16:14
 */
@Component @Aspect
public class DataSourceAspect {

    @Autowired
    private HttpServletRequest request;

    /**
     * 动态切换数据库
     * @param joinPoint
     */
    @Before(value = "execution(* com.xcwl.b2c.*.application.service.*.*(..))")
    public void dataSourceOption(JoinPoint joinPoint){
        String db=request.getParameter("db");
        if(StringUtils.isEmpty(db)){
            db=DataSourceOption.FUJIAN.name();
        }
        DataSourceContextHolder.setDataSourceHolder(DataSourceOption.valueOf(db));
    }
}
